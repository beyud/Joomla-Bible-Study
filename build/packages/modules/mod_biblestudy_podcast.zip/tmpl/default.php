<?php
/**
 * Podcast Model default
 *
 * @package     BibleStudy
 * @subpackage  Model.Podcast
 * @copyright   (C) 2007 - 2011 Joomla Bible Study Team All rights reserved
 * @license     http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link        http://www.JoomlaBibleStudy.org
 */
// No direct access
defined('_JEXEC') or die;
echo $subscribe;
