INSERT INTO `#__bsms_update` (id, version) VALUES (15, '8.0.4')
ON DUPLICATE KEY UPDATE version= '8.0.4';
