INSERT INTO `#__bsms_update` (id, version) VALUES (3, '7.0.1.1')
ON DUPLICATE KEY UPDATE version= '7.0.1.1';

-- 7.0.1.1
