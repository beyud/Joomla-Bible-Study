INSERT INTO `#__bsms_update` (id, version) VALUES (10, '7.1.3')
ON DUPLICATE KEY UPDATE version= '7.1.3';

-- need to make a update media table where auto start params where 0 need to be empty
