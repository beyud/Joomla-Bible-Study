DROP TABLE IF EXISTS `#__bsms_install`, `#__bsms_update`;
