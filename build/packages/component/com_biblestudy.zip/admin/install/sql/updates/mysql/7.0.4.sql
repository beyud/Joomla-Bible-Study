INSERT INTO `#__bsms_update` (id, version) VALUES (6, '7.0.4')
ON DUPLICATE KEY UPDATE version= '7.0.4';
