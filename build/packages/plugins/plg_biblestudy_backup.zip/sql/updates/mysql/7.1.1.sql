INSERT INTO `#__jbsbackup_update` (id,version) VALUES(3,'7.1.1')
ON DUPLICATE KEY UPDATE version= '7.1.1';