INSERT INTO `#__bsms_update` (id, version) VALUES (14, '8.0.3')
ON DUPLICATE KEY UPDATE version= '8.0.3';
