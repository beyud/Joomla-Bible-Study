INSERT INTO `#__bsms_update` (id, version) VALUES (16, '8.0.9')
ON DUPLICATE KEY UPDATE version= '8.0.8';
